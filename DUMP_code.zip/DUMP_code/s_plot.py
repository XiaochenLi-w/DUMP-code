import argparse
import os

import matplotlib.pyplot as plt
import yaml

def main():
    plt.style.use("seaborn-whitegrid")
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="./config/plot/s_kosarak2.yml")
    args = parser.parse_args()
    with open(args.config, "r") as f:
        config = yaml.safe_load(f)
        
    mse_eps1 = config["mse_eps1"]
    mse_eps2 = config["mse_eps2"]
    mse_eps3 = config["mse_eps3"]
    
    s_list = config["s_list"]
    
    fig, ax = plt.subplots(figsize = (4, 3))
    ax.set_ylabel("MSE", fontsize = 12)
    ax.set_xlabel("s", fontsize = 12)
    ax.set_xticks(s_list)
    ax.tick_params(axis="both", labelsize=8.5)
    
    ax.semilogy(s_list,
        mse_eps1,
        label = r"$epsilon$=0.6",
        marker = "*",
        markerfacecolor = 'none')
        
    ax.semilogy(s_list,
        mse_eps2,
        label = r"$epsilon$=0.8",
        marker = "o",
        markerfacecolor = 'none')
        
    ax.semilogy(s_list,
        mse_eps3,
        label = r"$epsilon$=1",
        marker = "+",
        markerfacecolor = 'none')
        
    ax.legend(fontsize=8.5)
    fig.tight_layout()
    filename = "s_kosarak2"
    fig.savefig(os.path.join("./fig", filename + ".png"), dpi=1200)
    fig.savefig(os.path.join("./fig/eps", filename + ".eps"), dpi=1200)

if __name__ == "__main__":
    main()