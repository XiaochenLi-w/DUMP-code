ipums: k: 0-899    n: 70187
Kosarak: k: 0-41266  n: 990002