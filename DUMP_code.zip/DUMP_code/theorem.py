import matplotlib.pyplot as plt
import seaborn as sns
import yaml
import os

import numpy as np

epsilon = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
epsilone = [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]

pureDUMP_mess = np.zeros(len(epsilon), dtype = float)
mixDUMP_mess = np.zeros(len(epsilon), dtype = float)
private_coin_mess = np.zeros(len(epsilon), dtype = float)
private_shuffle_mess = np.zeros(len(epsilon), dtype = float)
public_coin_mess = np.zeros(len(epsilone), dtype = float)
shuffle_based_mess = np.zeros(len(epsilon), dtype = float)

pureDUMP = np.zeros(len(epsilon), dtype = float)
mixDUMP = np.zeros(len(epsilon), dtype = float)
private_coin = np.zeros(len(epsilon), dtype = float)
private_shuffle = np.zeros(len(epsilon), dtype = float)
public_coin = np.zeros(len(epsilone), dtype = float)
shuffle_based = np.zeros(len(epsilon), dtype = float)
solh = np.zeros(len(epsilon), dtype = float)

n = 602325
k = 915
delta = 1.0e-6

for idex, eps in enumerate(epsilon):
    pureDUMP_mess[idex] = k * np.log(1/delta) / (n * eps**2)
    mixDUMP_mess[idex] =  k * np.log(1/delta) / (n * eps**2)
    private_shuffle_mess[idex] = k
    private_coin_mess[idex] = np.log(1/(eps * delta)) / eps**2
    shuffle_based_mess[idex] = 1

for idex, eps in enumerate(epsilone):
    public_coin_mess[idex] = np.power(np.log(k), 3) * np.log(np.log(k)/delta) / eps**2


for idex, eps in enumerate(epsilon):
    pureDUMP[idex] = np.sqrt(np.log(1/delta)) / (n * eps)
    mixDUMP[idex] =  np.sqrt(np.log(1/delta)) * (1 + k / (np.power(np.e, 10 * eps) - 1)) / (n * eps)
    private_shuffle[idex] = np.log(1 / delta) / (eps**2 * n)
    private_coin[idex] = np.log(k) / n + np.sqrt(np.log(k) * np.log(1/(eps * delta))) / (eps * n)
    shuffle_based[idex] = np.power(np.log(1/delta), 1/3) / (np.power(n, 5/6) * np.power(eps, 2/3))
    # m = eps**2 * (n - 1) / (14 * np.log(2 / delta))
    # d = np.floor((m + 2) / 3)
    # solh[idex] = m**2 / (n * (m - d)**2 * (d - 1))
    solh[idex] = eps**2 * np.log(2 / delta) / np.power(eps**2 * (n-1) - np.log(2 / delta), 3)

for idex, eps in enumerate(epsilone):
    public_coin[idex] = np.power(np.log(k), 3/2) * np.sqrt(np.log(np.log(k) / delta)) / (eps * n)

color_list = sns.color_palette("bright", 8)
fig = plt.figure(figsize = (10, 5))

ax = plt.subplot(1,2,1)
ax.set_ylabel("MSE", fontsize = 12)
ax.set_xlabel(r"$\epsilon$", fontsize = 12)
ax.set_xticks(epsilon)
ax.tick_params(axis="both", labelsize=8.5)
ax.set_title("(a)",y=-0.4, fontsize = 20)

l1 = ax.semilogy(epsilon,
            shuffle_based,
            label = "shuffle-based",
            color = color_list[4],
            marker = "d",
            markerfacecolor = 'none')

l2 = ax.semilogy(epsilon,
            private_coin,
            label = "private-coin",
            color = color_list[1],
            marker = "s",
            markerfacecolor = 'none')

l3 = ax.semilogy(epsilone,
            public_coin,
            label = "public-coin",
            color = color_list[2],
            marker = "^",
            markerfacecolor = 'none')

l4 = ax.semilogy(epsilon,
            private_shuffle,
            label = "private-shuffle",
            color = color_list[5],
            marker = "+",
            markerfacecolor = 'none')

l5 = ax.semilogy(epsilon,
            pureDUMP,
            label = "pureDUMP",
            color = color_list[0],
            marker = "*",
            markerfacecolor = 'none')

l6 = ax.semilogy(epsilon,
            mixDUMP,
            label = "mixDUMP",
            color = color_list[3],
            marker = "o",
            markerfacecolor = 'none')

l7 = ax.semilogy(epsilon,
            solh,
            label = "SOLH",
            color = color_list[6],
            marker = "x",
            markerfacecolor = 'none')
#--------------------------------------------------------
ax = plt.subplot(1,2,2)
ax.set_ylabel("number of messages", fontsize = 12)
ax.set_xlabel(r"$\epsilon$", fontsize = 12)
ax.set_xticks(epsilon)
ax.tick_params(axis="both", labelsize=8.5)
ax.set_title("(b)",y=-0.4, fontsize = 20)

l1 = ax.semilogy(epsilon,
            shuffle_based_mess,
            label = "shuffle-based",
            color = color_list[4],
            marker = "d",
            markerfacecolor = 'none')

l2 = ax.semilogy(epsilon,
            private_coin_mess,
            label = "private-coin",
            color = color_list[1],
            marker = "s",
            markerfacecolor = 'none')

l3 = ax.semilogy(epsilone,
            public_coin_mess,
            label = "public-coin",
            color = color_list[2],
            marker = "^",
            markerfacecolor = 'none')

l4 = ax.semilogy(epsilon,
            private_shuffle_mess,
            label = "private-shuffle",
            color = color_list[5],
            marker = "+",
            markerfacecolor = 'none')

l5 = ax.semilogy(epsilon,
            pureDUMP_mess,
            label = "pureDUMP",
            color = color_list[0],
            marker = "*",
            markerfacecolor = 'none')

l6 = ax.semilogy(epsilon,
            mixDUMP_mess,
            label = "mixDUMP",
            color = color_list[3],
            marker = "o",
            markerfacecolor = 'none')

legend_list = ['shuffle-based', 'private-coin', 'public-coin', 'private-shuffle', 'pureDUMP', 'mixDUMP', 'SOLH'] 
fig.legend([l1, l2, l3, l4, l5, l6, l7], labels =legend_list, loc='center', bbox_to_anchor=(0.5, 0.92), ncol=3, prop = {'size':14}, frameon = True, edgecolor = 'gray')

fig.tight_layout()
fig.subplots_adjust(left = 0.067, bottom = 0.252, right = 0.974, top = 0.845, wspace = 0.171, hspace = 0.2)
plt.show()
# filename = "k_500_theorem"
# fig.savefig(os.path.join("./fig/theorem", filename + ".png"), dpi=3000)
# fig.savefig(os.path.join("./fig/eps", filename + ".pdf"), dpi=3000)