import numpy as np
import matplotlib.pyplot as plt
import xxhash
import random
   
def main():
    '''
    epsilon_l = np.zeros([3,10], dtype = float)
    epsilon_nv = np.zeros([3,10], dtype = float)
    #s_nv = np.zeros([3,10], dtype = float)
    
    epsilon = [0.3]
    delta = 1.0e-6
    n=70187
    k=900
    s = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    for i, value in enumerate(epsilon):
        for j, num in enumerate(s):
            
             epsilon_l[i, j] = np.log(np.square(np.square(value) * n * num / (14 * np.sqrt(k) * np.log(4 / delta))) +1 - k)
             lambda_ = k / (np.exp(epsilon_l[i, j] + k - 1) * (k-1))
             epsilon_nv[i, j] = np.sqrt(14 * k * np.log(4 / delta) / (n * num + (n-1) * lambda_ - np.sqrt(2 * (n-1) * lambda_ * np.log(2 / delta)) - 1))
            #s_nv[i, j] = (14 * k * np.log(4 / delta) / value**2 + 1 + np.sqrt(2 * (n-1) * lambda_ * np.log(2 / delta)) - (n-1) * lambda_) / n
            
            temp = 4 * (n - 1) * (14 * k * np.log(4 / delta) / value**2 + 1 - n * num)
            print(temp)
            lambda_ = np.square((np.sqrt(2 * (n - 1) * np.log(2 / delta)) - np.sqrt(2 * (n - 1) * np.log(2 / delta) + temp)) / (2 * (n - 1)))
            #epsilon_l[i, j] = np.log((k-1) / (lambda_) + 1 - k)
            epsilon_l[i, j] = lambda_
      
    print(epsilon_l)
    #print(epsilon_nv)
    '''
    '''
    v = [20, 30, 80, 90, 120]
    g = 10
    for i, num in enumerate(v):
        x = (xxhash.xxh32(str(num), seed=i).intdigest() % g)
        print(x)
    '''
    x = max(1, 2)
    print(x)


if __name__ == "__main__":
    main()